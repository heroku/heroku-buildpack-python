==============
Extra Wrappers
==============

.. automodule:: werkzeug.contrib.wrappers

.. autoclass:: JSONRequestMixin
   :members:

.. autoclass:: ProtobufRequestMixin
   :members:

.. autoclass:: RoutingArgsRequestMixin
   :members:

.. autoclass:: ReverseSlashBehaviorRequestMixin
   :members:

.. autoclass:: DynamicCharsetRequestMixin
   :members:

.. autoclass:: DynamicCharsetResponseMixin
   :members:
